<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-pink-50">

  <!-- Header -->
  <header class="bg-pink-100 shadow-md">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center flex-wrap">

     <!-- Logo -->
     <div class="flex items-center space-x-2">
        <img src="images/logo1.png" alt="ALORA Logo" class="w-20 h-15">
      </div>

      <!-- Left Navigation Links -->
      <div class="flex space-x-4">
        <a href="index.php" class="flex items-center space-x-2 text-pink-600 hover:text-pink-800 font-semibold">
          <span>Home</span>
        </a>
        <a href="aboutUs.php" class="flex items-center space-x-2 text-pink-600 hover:text-pink-800 font-semibold">
          <span>About Us</span>
        </a>
        <a href="productList.php" class="flex items-center space-x-2 text-pink-600 hover:text-pink-800 font-semibold">
          <span>Products</span>
        </a>
        <a href="faq.php" class="flex items-center space-x-2 text-pink-600 hover:text-pink-800 font-semibold">
          <span>FAQs</span>
        </a>
        <a href="contactUs.php" class="flex items-center space-x-2 text-pink-600 hover:text-pink-800 font-semibold">
          <span>Contact Us</span>
        </a>
        <a href="services.php" class="flex items-center space-x-2 text-pink-600 hover:text-pink-800 font-semibold">
          <span>Services</span>
        </a>
        <a href="points.php" class="flex items-center space-x-2 text-pink-600 hover:text-pink-800 font-semibold">
          <span>Points</span>
        </a>
        
        <!-- Categories Dropdown -->
        <div class="relative">
          <button onclick="toggleCategories()" class="flex items-center space-x-2 text-pink-600 hover:text-pink-800 font-semibold">
            <span>Categories</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-pink-600" viewBox="0 0 20 20" fill="currentColor">
              <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
            </svg>
          </button>
          <!-- Category List -->
          <div id="category-list" class="absolute mt-2 w-48 bg-white rounded-lg shadow-lg hidden">
            <ul class="py-2 text-pink-600">
              <li><a href="#" class="block px-4 py-2 text-sm hover:bg-pink-100">Birthday Flowers</a></li>
              <li><a href="#" class="block px-4 py-2 text-sm hover:bg-pink-100">Anniversary Flowers</a></li>
              <li><a href="#" class="block px-4 py-2 text-sm hover:bg-pink-100">Wedding FLowers</a></li>
              <li><a href="#" class="block px-4 py-2 text-sm hover:bg-pink-100">Customize Flowers</a></li>
              <li><a href="#" class="block px-4 py-2 text-sm hover:bg-pink-100">Choko boxes</a></li>
              <li><a href="#" class="block px-4 py-2 text-sm hover:bg-pink-100">Customize Chokos</a></li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Sorting and Price Filter -->
      <div class="flex items-center space-x-4">
        <select id="sort-price" class="px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
          <option value="low-to-high">Price order: Low to High</option>
          <option value="high-to-low">Price order: High to Low</option>
        </select>
      </div>

      <!-- Right Side Icons -->
      <div class="flex space-x-6">
        <!-- Cart Icon -->
        <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 fill-rose-500 cursor-pointer" viewBox="0 0 24 24" onclick="navigateTo('cart.php')">
          <path d="M3 3h2l3.6 7.59-1.35 2.45A1.99 1.99 0 0 0 7 14a2 2 0 1 0 2 2h8a2 2 0 1 0 2-2H8.42c-.1-.31-.31-.59-.58-.76l1.16-2.1h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49L21.1 3H3z" />
        </svg>

        <!-- Profile Icon -->
        <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 fill-rose-500 cursor-pointer" viewBox="0 0 24 24" onclick="navigateTo('login.php')">
          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-3.31 0-6 2.69-6 6h12c0-3.31-2.69-6-6-6z" />
        </svg>
      </div>
    </div>
  </header>

  <!-- JavaScript for Navigation and Category Toggle -->
  <script>
    function navigateTo(page) {
      window.location.href = page; // Navigate to the specified page
    }

    function toggleCategories() {
      const categoryList = document.getElementById('category-list');
      categoryList.classList.toggle('hidden'); // Toggle visibility of category list
    }

    // Sorting by price functionality
    document.getElementById('sort-price').addEventListener('change', function() {
      const sortValue = this.value;
      // You can implement sorting logic here based on the selected value
      alert(`Sorting products by: ${sortValue}`);
    });
  </script>

</body>
</html>
