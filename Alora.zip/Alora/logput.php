<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Logout - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-pink-50">

  <!-- Header -->
  <header class="bg-pink-100 shadow-md">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center flex-wrap">
      <div class="flex space-x-4">
        <a href="#home" class="text-pink-600 hover:text-pink-800 font-semibold">Home</a>
        <a href="#products" class="text-pink-600 hover:text-pink-800 font-semibold">Products</a>
        <a href="#faqs" class="text-pink-600 hover:text-pink-800 font-semibold">FAQs</a>
        <a href="#contact" class="text-pink-600 hover:text-pink-800 font-semibold">Contact</a>
      </div>
      <div class="flex space-x-4 ml-auto mt-4 md:mt-0">
        <a href="#login" class="text-pink-600 hover:text-pink-800 font-semibold">Login</a>
      </div>
    </div>
  </header>

  <!-- Logout Section -->
  <section class="flex justify-center items-center min-h-screen bg-pink-50">
    <div class="bg-white rounded-lg shadow-md p-8 w-full max-w-md">
      <h2 class="text-3xl font-bold text-pink-700 text-center mb-6">Logout</h2>
      
      <!-- Logout Confirmation -->
      <p class="text-lg text-gray-700 text-center mb-6">Are you sure you want to log out?</p>

      <!-- Logout Buttons -->
      <div class="space-x-4 flex justify-center">
        <a href="#home" class="bg-pink-600 text-white px-6 py-2 rounded-lg hover:bg-pink-700 transition">Yes, Log Out</a>
        <a href="#dashboard" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition">Cancel</a>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-pink-100 py-8 text-center text-pink-600">
    <p>&copy; 2024 ALORA Blossom and Gift Garden. All rights reserved.</p>
  </footer>

</body>
</html>
