<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Points Dashboard - ALORA Blossom and Gift Garden</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include('navbar.php'); ?>
    <script>
        // Simulated data
        let points = 550; // Example: User has 550 points
        const pointsPerItem = 10; // Points earned per item
        const pointsThreshold = 500;
        const conversionRate = 5; // 1 point = 5 rupees

        // Convert points to rupees
        function convertPointsToRupees(points) {
            return points >= pointsThreshold ? (points - pointsThreshold) * conversionRate : 0;
        }

        // Update the dashboard
        function updateDashboard() {
            const pointsElement = document.getElementById("points");
            const rupeesElement = document.getElementById("rupees");
            const redeemButton = document.getElementById("redeem-button");
            const messageElement = document.getElementById("message");

            // Update points
            pointsElement.textContent = points;

            // Convert points to rupees and display
            const rupees = convertPointsToRupees(points);
            rupeesElement.textContent = `₹${rupees.toFixed(2)}`;

            // Enable/Disable redeem button based on available rupees
            if (rupees > 0) {
                redeemButton.disabled = false;
                messageElement.textContent = `You have ₹${rupees.toFixed(2)} available for purchases!`;
            } else {
                redeemButton.disabled = true;
                messageElement.textContent = "Earn points to redeem rewards!";
            }
        }

        // Redeem points for rupees
        function redeemPoints() {
            const rupees = convertPointsToRupees(points);
            if (rupees > 0) {
                alert(`You've redeemed ₹${rupees.toFixed(2)} for a purchase!`);
                points -= Math.floor(rupees / conversionRate); // Deduct points based on redemption
                updateDashboard(); // Refresh the dashboard
            } else {
                alert("Not enough points to redeem.");
            }
        }

        // Initialize the dashboard
        window.onload = function() {
            updateDashboard();
        };
    </script>
</head>
<body class="bg-pink-50">

    <!-- Points Dashboard Section -->
    <section class="flex justify-center items-center min-h-screen bg-pink-50">
        <div class="bg-white rounded-lg shadow-lg p-8 w-full max-w-md">
            <h2 class="text-3xl font-bold text-pink-700 text-center mb-6">Your Points Dashboard</h2>

            <!-- Current Points -->
            <div class="flex justify-between items-center">
                <p class="text-lg font-medium text-pink-600">Current Points:</p>
                <p id="points" class="text-2xl font-bold text-pink-700">0</p>
            </div>

            <!-- Rupees from Points -->
            <div class="flex justify-between items-center mt-4">
                <p class="text-lg font-medium text-pink-600">Converted Rupees:</p>
                <p id="rupees" class="text-2xl font-bold text-pink-700">₹0.00</p>
            </div>

            <!-- Redemption Message -->
            <div id="message" class="mt-4 text-center text-pink-500 font-medium"></div>

            <!-- Redeem Points Button -->
            <div class="mt-6 text-center">
                <button id="redeem-button" onclick="redeemPoints()" 
                        class="bg-pink-600 text-white py-2 px-6 rounded-lg hover:bg-pink-700 transition" 
                        disabled>Redeem Points</button>
            </div>
        </div>
    </section>
    <?php include('footer.php'); ?>

</body>
</html>
