<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - ALORA Blossom and Gift Garden</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include('navbar.php'); ?>
</head>
<body class="bg-pink-50">

    <!-- Checkout Section -->
    <section id="checkout" class="py-16 bg-pink-100">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-pink-700 mb-6 text-center">Checkout</h2>

            <!-- Checkout Form and Summary -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                <!-- Customer Details Form -->
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <h3 class="text-2xl font-bold text-pink-700 mb-4">Your Details</h3>
                    <form id="checkoutForm" action="transaction.php" method="POST" class="space-y-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-1" for="name">Full Name <span class="text-red-500">*</span></label>
                            <input type="text" id="name" name="name" class="w-full p-3 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-400" placeholder="Enter your name" required>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-1" for="email">Email Address <span class="text-red-500">*</span></label>
                            <input type="email" id="email" name="email" class="w-full p-3 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-400" placeholder="Enter your email" required>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-1" for="address">Shipping Address <span class="text-red-500">*</span></label>
                            <input type="text" id="address" name="address" class="w-full p-3 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-400" placeholder="Enter your shipping address" required>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-1" for="phone">Contact Number <span class="text-red-500">*</span></label>
                            <input type="tel" id="phone" name="phone" class="w-full p-3 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-400" placeholder="Enter your contact number" required>
                        </div>
                        <button type="submit" class="w-full bg-pink-600 text-white py-3 rounded-lg hover:bg-pink-700 transition">Place Order</button>
                    </form>
                </div>

                <!-- Order Summary -->
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <h3 class="text-2xl font-bold text-pink-700 mb-4">Order Summary</h3>
                    <div class="space-y-4">
                        <!-- Example Product 1 -->
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-4">
                                <img src="images/rose.png" alt="Rose Bouquet" class="w-16 h-16 rounded-lg">
                                <div>
                                    <p class="font-semibold text-pink-700">Rose Bouquet</p>
                                    <p class="text-gray-600">Quantity: 2</p>
                                </div>
                            </div>
                            <p class="font-semibold text-gray-700">$40.00</p>
                        </div>
                        <!-- Example Product 2 -->
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-4">
                                <img src="images/rose12.png" alt="Tulip Bouquet" class="w-16 h-16 rounded-lg">
                                <div>
                                    <p class="font-semibold text-pink-700">Tulip Bouquet</p>
                                    <p class="text-gray-600">Quantity: 1</p>
                                </div>
                            </div>
                            <p class="font-semibold text-gray-700">$30.00</p>
                        </div>
                    </div>

                    <!-- Total Price -->
                    <div class="border-t border-gray-200 mt-4 pt-4">
                        <div class="flex items-center justify-between">
                            <p class="font-semibold text-gray-700">Subtotal</p>
                            <p class="font-semibold text-gray-700">$70.00</p>
                        </div>
                        <div class="flex items-center justify-between mt-2">
                            <p class="font-semibold text-gray-700">Shipping</p>
                            <p class="font-semibold text-gray-700">$5.00</p>
                        </div>
                        <div class="flex items-center justify-between mt-4 text-lg">
                            <p class="font-bold text-gray-800">Total</p>
                            <p class="font-bold text-gray-800">$75.00</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include('footer.php'); ?>

</body>
</html>
