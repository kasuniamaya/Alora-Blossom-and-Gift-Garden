<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <?php include('navbar.php'); ?>
</head>
<body class="bg-pink-50">

  <!-- Contact Us Section -->
  <section id="contact" class="py-16 bg-pink-100">
    <div class="container mx-auto px-4 text-center">
      <h2 class="text-3xl font-bold text-pink-700 mb-6">Get in Touch</h2>
      <p class="text-lg text-gray-700 mb-6">Have any questions or inquiries? Feel free to contact us anytime! We're here to help.</p>

      <!-- Contact Form -->
      <form id="contactForm" class="max-w-lg mx-auto space-y-6">
        <div class="text-left">
          <label for="name" class="text-lg font-semibold text-pink-700">Your Name <span class="text-red-500">*</span></label>
          <input 
            type="text" 
            id="name"
            name="name" 
            placeholder="Your Name" 
            class="w-full p-3 rounded-lg border border-pink-300 focus:outline-none focus:ring-2 focus:ring-pink-400" 
            required>
        </div>

        <div class="text-left">
          <label for="email" class="text-lg font-semibold text-pink-700">Your Email <span class="text-red-500">*</span></label>
          <input 
            type="email" 
            id="email"
            name="email" 
            placeholder="Your Email" 
            class="w-full p-3 rounded-lg border border-pink-300 focus:outline-none focus:ring-2 focus:ring-pink-400" 
            required>
        </div>

        <div class="text-left">
          <label for="contact" class="text-lg font-semibold text-pink-700">Your Contact Number <span class="text-red-500">*</span></label>
          <input 
            type="tel" 
            id="contact"
            name="contact" 
            placeholder="Your Contact Number" 
            class="w-full p-3 rounded-lg border border-pink-300 focus:outline-none focus:ring-2 focus:ring-pink-400" 
            pattern="[0-9]{10}" 
            title="Please enter a valid 10-digit contact number." 
            required>
        </div>

        <div class="text-left">
          <label for="message" class="text-lg font-semibold text-pink-700">Your Message</label>
          <textarea 
            name="message" 
            id="message"
            placeholder="Your Message" 
            rows="4" 
            class="w-full p-3 rounded-lg border border-pink-300 focus:outline-none focus:ring-2 focus:ring-pink-400">
          </textarea>
        </div>

        <button 
          type="button" 
          id="sendMessageButton"
          class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">
          Send Message
        </button>
      </form>
    </div>
  </section>

  <!-- Custom Message Component -->
  <div id="messageContainer" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg text-center space-y-4">
      <h3 class="text-xl font-bold text-pink-700">Message Sent Successfully!</h3>
      <p class="text-gray-600">Thank you for contacting us. We'll get back to you shortly.</p>
      <button id="closeMessageButton" class="bg-pink-600 text-white py-2 px-4 rounded-lg hover:bg-pink-700 transition">
        Close
      </button>
    </div>
  </div>

  <script>
    // DOM Elements
    const sendMessageButton = document.getElementById('sendMessageButton');
    const messageContainer = document.getElementById('messageContainer');
    const closeMessageButton = document.getElementById('closeMessageButton');

    // Event Listener for Send Message Button
    sendMessageButton.addEventListener('click', () => {
      // Show the message container
      messageContainer.classList.remove('hidden');
    });

    // Event Listener for Close Button
    closeMessageButton.addEventListener('click', () => {
      // Hide the message container
      messageContainer.classList.add('hidden');
    });
  </script>

    <!-- Google Map Embed -->
    <div class="mt-12">
        <h4 class="text-xl font-semibold text-pink-700 mb-4">Our Location</h4>
        <!-- Replace the src URL with your actual Google Map Embed link -->
        <iframe src="https://www.google.com/maps/embed?pb=YOUR_EMBED_LINK_HERE" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
      </div>

  <?php include('footer.php'); ?>
</body>
</html>
