<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Products - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <?php include('navbar.php'); ?>
</head>
<body class="bg-pink-50">

<section id="flowerBouquets" class="py-16 bg-white">
  <div class="container mx-auto px-4">
    <h2 class="text-3xl font-bold text-pink-700 text-center mb-8">Our Flower Bouquets</h2>
    
    <!-- Grid for displaying flower bouquets -->
    <div id="flowerList" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
      <!-- Flower Bouquet Items 1  -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko9.jpg" alt="Flower 1" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 1</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item2 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item3 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko1.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item4 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko2.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item5 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko3.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item6 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko4.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item7 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko5.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item8 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko6.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item9 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko7.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item10 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko8.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item11 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko10.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item12 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko11.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item13 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko12.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item14 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko13.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item15 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko14.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item16 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko15.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item17 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko16.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item18 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko17.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item19 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko18.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item20 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko19.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item21 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko20.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item22 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/choko21.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item23 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose3.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item24 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose4.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item25 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose5.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item26 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose6.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item27 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose7.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item28 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose8.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item29 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose9.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item30 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose10.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item31 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose11.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item32 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose12.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item33 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose13.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>


    <!-- item34 -->
    <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose14.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item35 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose15.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item36 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose17.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item37 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose18.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item38 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose19.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item39 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose20.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item40 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose21.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item41 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose22.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item42 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose23.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item43 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose24.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item44 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose25.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item45 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose26.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item46 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose27.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item47 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose28.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item48 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose29.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item49 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose30.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item50 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose31.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- item51 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose32.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

     

      



    </div>
  </div>
</section>

  
    <!-- See More Button (Now Navigates to All Products Page) -->
    <div class="text-center mt-8">
      <a href="allProducts.php" class="text-pink-600 hover:text-pink-800 font-semibold">
        See More...
      </a>
    </div>
  </div>
</section>


  <?php include('footer.php'); ?>

</body>
</html>
