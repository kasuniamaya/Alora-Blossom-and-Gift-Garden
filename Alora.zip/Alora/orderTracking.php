<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Tracking - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <?php include('navbar.php'); ?>
</head>
<body class="bg-pink-50">

  <!-- Header -->
  <header class="bg-pink-100 shadow-md">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center flex-wrap">
      <div class="flex space-x-4">
        <a href="#home" class="text-pink-600 hover:text-pink-800 font-semibold">Home</a>
        <a href="#products" class="text-pink-600 hover:text-pink-800 font-semibold">Products</a>
        <a href="#faqs" class="text-pink-600 hover:text-pink-800 font-semibold">FAQs</a>
        <a href="#contact" class="text-pink-600 hover:text-pink-800 font-semibold">Contact</a>
      </div>
      <div class="flex space-x-4 ml-auto mt-4 md:mt-0">
        <a href="#login" class="text-pink-600 hover:text-pink-800 font-semibold">Login</a>
      </div>
    </div>
  </header>

  <!-- Order Tracking Section -->
  <section class="flex justify-center items-center min-h-screen bg-pink-50">
    <div class="bg-white rounded-lg shadow-md p-8 w-full max-w-lg">
      <h2 class="text-3xl font-bold text-pink-700 text-center mb-6">Track Your Order</h2>
      
      <!-- Order Tracking Form -->
      <form class="space-y-6">
        <!-- Order Number Input -->
        <div class="flex flex-col">
          <label for="order-number" class="text-pink-600">Order Number</label>
          <input type="text" id="order-number" name="order-number" placeholder="Enter your order number" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
        </div>

        <!-- Track Button -->
        <div class="text-center">
          <button type="button" class="bg-pink-600 text-white px-6 py-2 rounded-lg hover:bg-pink-700 transition">
            Track Order
          </button>
        </div>
      </form>

      <!-- Order Details Section -->
      <div class="mt-8 hidden" id="order-details">
        <div class="text-center">
          <h3 class="text-2xl font-semibold text-pink-700">Order #123456</h3>
          <p class="text-lg text-gray-700 mt-2">Status: <span class="text-green-600">Shipped</span></p>
          <p class="text-gray-500 mt-1">Estimated Delivery Date: <span class="font-semibold">Jan 5, 2024</span></p>
          <p class="text-gray-500 mt-1">Carrier: <span class="font-semibold">FedEx</span></p>

          <div class="mt-4 text-left">
            <h4 class="text-xl font-bold text-pink-600">Shipping Details</h4>
            <p class="text-gray-700 mt-2">Address: <span class="font-semibold">123 Blossom St, Gift Garden, NY, 10001</span></p>
            <p class="text-gray-700 mt-1">Tracking Number: <span class="font-semibold">9876543210</span></p>
          </div>
        </div>
      </div>

    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-pink-100 py-8 text-center text-pink-600">
    <p>&copy; 2024 ALORA Blossom and Gift Garden. All rights reserved.</p>
  </footer>

  <!-- JavaScript for Simulating Tracking -->
  <script>
    const trackButton = document.querySelector("button");
    const orderDetails = document.getElementById("order-details");

    trackButton.addEventListener("click", () => {
      // Simulating order tracking
      const orderNumber = document.getElementById("order-number").value;
      
      if (orderNumber === "123456") {
        orderDetails.classList.remove("hidden");
      } else {
        alert("Order number not found.");
      }
    });
  </script>

<?php include('footer.php'); ?>
</body>
</html>
