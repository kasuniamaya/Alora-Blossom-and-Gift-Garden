<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Transaction - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <?php include('navbar.php'); ?>
</head>
<body class="bg-pink-50">

  <!-- Header -->
  <header class="bg-pink-100 shadow-md">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center flex-wrap">
      <div class="flex space-x-4">
        <a href="#home" class="text-pink-600 hover:text-pink-800 font-semibold">Home</a>
        <a href="#products" class="text-pink-600 hover:text-pink-800 font-semibold">Products</a>
        <a href="#faqs" class="text-pink-600 hover:text-pink-800 font-semibold">FAQs</a>
        <a href="#contact" class="text-pink-600 hover:text-pink-800 font-semibold">Contact</a>
      </div>
      <div class="flex space-x-4 ml-auto mt-4 md:mt-0">
        <a href="#cart" class="text-pink-600 hover:text-pink-800 font-semibold">Cart</a>
      </div>
    </div>
  </header>

  <!-- Transaction Section -->
  <section class="py-16 bg-pink-50">
    <div class="container mx-auto px-4">
      <h2 class="text-3xl font-bold text-pink-700 text-center mb-8">Transaction Details</h2>
      <div class="bg-white rounded-lg shadow-md p-8">
        
        <!-- Transaction Details -->
        <div class="mb-8">
          <h3 class="text-xl font-semibold text-pink-700 mb-4">Order Summary</h3>
          <div class="space-y-4">
            <!-- Product Details -->
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">Flower Bouquet 1</span>
              <span class="text-gray-600">$20.00</span>
            </div>
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">Flower Bouquet 2</span>
              <span class="text-gray-600">$25.00</span>
            </div>
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">Flower Bouquet 3</span>
              <span class="text-gray-600">$30.00</span>
            </div>
          </div>
        </div>

        <!-- Total -->
        <div class="flex justify-between items-center font-semibold mb-8">
          <span class="text-lg text-gray-800">Total</span>
          <span class="text-xl text-pink-700">$75.00</span>
        </div>

        <!-- Billing Information -->
        <div class="mb-8">
          <h3 class="text-xl font-semibold text-pink-700 mb-4">Billing Information</h3>
          <div class="space-y-4">
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">Name:</span>
              <span class="text-gray-600">John Doe</span>
            </div>
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">Email:</span>
              <span class="text-gray-600">john.doe@example.com</span>
            </div>
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">Address:</span>
              <span class="text-gray-600">123 Main St, Springfield, IL</span>
            </div>
          </div>
        </div>

        <!-- Payment Type Selection -->
        <div class="mb-8">
          <h3 class="text-xl font-semibold text-pink-700 mb-4">Select Payment Method</h3>
          <div class="space-y-4">
            <div>
              <input type="radio" id="credit-card" name="payment-type" value="credit-card" class="mr-2">
              <label for="credit-card" class="font-medium text-gray-700">Credit/Debit Card</label>
            </div>
            <div>
              <input type="radio" id="paypal" name="payment-type" value="paypal" class="mr-2">
              <label for="paypal" class="font-medium text-gray-700">PayPal</label>
            </div>
           
          </div>
        </div>

        <!-- Payment Section (only visible if Credit/Debit card is selected) -->
        <div id="payment-section" class="space-y-6">
          <h3 class="text-xl font-semibold text-pink-700">Payment</h3>
          <div class="space-y-4">
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">Card Number</span>
              <input type="text" class="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none" placeholder="**** **** **** ****" id="card-number">
            </div>
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">Expiration Date</span>
              <input type="text" class="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none" placeholder="MM/YY" id="expiry-date">
            </div>
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-700">CVV</span>
              <input type="text" class="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none" placeholder="***" id="cvv">
            </div>
          </div>
        </div>

        <!-- Payment Button -->
        <div class="mt-6">
          <button onclick="processPayment()" class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Process Payment</button>
        </div>
      </div>
    </div>
  </section>

  <script>
    // Show payment section only if "Credit/Debit Card" is selected
    document.querySelectorAll('input[name="payment-type"]').forEach((radio) => {
      radio.addEventListener('change', (event) => {
        const paymentType = event.target.value;
        const paymentSection = document.getElementById('payment-section');

        if (paymentType === 'credit-card') {
          paymentSection.style.display = 'block';
        } else {
          paymentSection.style.display = 'none';
        }
      });
    });

    function processPayment() {
      alert("Payment successfully processed! Thank you for your purchase.");
      // Here you could integrate with a payment gateway or backend system to handle payment.
    }
  </script>

<?php include('footer.php'); ?>

</body>
</html>
