<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <?php include('navbar.php'); ?>
  <script>
    function validateForm(event) {
      event.preventDefault(); // Prevent form submission if validation fails

      var username = document.getElementById("username").value;
      var password = document.getElementById("password").value;
      var usernameError = document.getElementById("username-error");
      var passwordError = document.getElementById("password-error");

      // Reset error messages
      usernameError.textContent = "";
      passwordError.textContent = "";

      var valid = true;

      // Validate username
      if (username.trim() === "") {
        usernameError.textContent = "Username is required.";
        valid = false;
      }

      // Validate password
      if (password.trim() === "") {
        passwordError.textContent = "Password is required.";
        valid = false;
      }

      // If form is valid, submit it
      if (valid) {
        alert("Form submitted successfully!");
        document.getElementById("login-form").submit();
      }
    }

    // Toggle Password Visibility
    function togglePassword() {
      var passwordField = document.getElementById("password");
      var eyeIcon = document.getElementById("eye-icon");

      if (passwordField.type === "password") {
        passwordField.type = "text"; // Show password
        eyeIcon.textContent = "visibility"; // Change icon to 'visibility' when password is visible
      } else {
        passwordField.type = "password"; // Hide password
        eyeIcon.textContent = "visibility_off"; // Change icon to 'visibility_off' when password is hidden
      }
    }
  </script>
</head>
<body class="bg-pink-50">



  <!-- Main Content Section -->
  <section class="flex min-h-screen">
    <!-- Left Side: Image and New Customer Info -->
    <div class="w-1/2 bg-pink-200 flex justify-center items-center p-8">
      <div class="text-center">
        <img src="images/login.jpg" alt="Flower Image" class="mx-auto mb-6 rounded-lg shadow-lg">
        <h3 class="text-2xl font-bold text-pink-700 mb-4">New to ALORA Blossom?</h3>
        <p class="text-lg text-gray-700 mb-6">Create a new account and explore our beautiful selection of flowers and gift boxes!</p>
        <a href="signUp.php" class="bg-pink-600 text-white py-2 px-6 rounded-lg hover:bg-pink-700 transition">Create New Account</a>
      </div>
    </div>

    <!-- Right Side: Login Form -->
    <div class="w-1/2 bg-white flex justify-center items-center p-8">
      <div class="w-full max-w-sm">
        <h2 class="text-3xl font-bold text-pink-700 text-center mb-6">Login</h2>
        
        <!-- Login Form -->
        <form id="login-form" onsubmit="validateForm(event)" method="POST" class="space-y-6">
          <!-- Username -->
          <div class="flex flex-col">
            <label for="username" class="text-pink-600">
              Username <span class="text-red-500">*</span>
            </label>
            <input type="text" id="username" name="username" placeholder="Enter your username" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent" required>
            <p id="username-error" class="text-red-500 text-sm mt-2"></p>
          </div>

          <!-- Password -->
          <div class="flex flex-col relative">
            <label for="password" class="text-pink-600">
              Password <span class="text-red-500">*</span>
            </label>
            <input type="password" id="password" name="password" placeholder="Enter your password" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent" required>
            <button type="button" onclick="togglePassword()" class="absolute right-3 top-10 text-pink-600">
              <span id="eye-icon" class="material-icons">visibility_off</span>
            </button>
            <p id="password-error" class="text-red-500 text-sm mt-2"></p>
          </div>

          <!-- Login Button -->
          <div>
            <button type="submit" class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">
              Login
            </button>
          </div>

          <!-- Forgot Password Link -->
          <div class="text-center">
            <a href="#forgot" class="text-pink-600 hover:text-pink-800">Forgot your password?</a>
          </div>
        </form>
      </div>
    </div>
  </section>

  <?php include('footer.php'); ?>

</body>
</html>
