<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <?php include('navbar.php'); ?>
</head>
<body class="bg-pink-50">

  <!-- Services Section -->
  <section id="services" class="py-16 bg-pink-100">
    <div class="container mx-auto px-4 text-center">
      <h2 class="text-3xl font-bold text-pink-700 mb-6">Our Services</h2>
      <p class="text-lg text-gray-700 mb-8">At ALORA Blossom and Gift Garden, we provide a variety of customized services to make your special moments memorable.</p>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        
        <!-- Service 1 -->
        <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
          <img src="images/flowerArrangements.jpg" alt="Flower Arrangement" class="w-full h-40 object-cover rounded-lg mb-4">
          <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Arrangements</h3>
          <p class="text-gray-600">Elegant and fresh flower arrangements for all occasions, including weddings, birthdays, and anniversaries.</p>
        </div>
        
        <!-- Service 2 -->
        <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
          <img src="images/customizedGiftBoxes.jpg" alt="Customized Gift Boxes" class="w-full h-40 object-cover rounded-lg mb-4">
          <h3 class="text-xl font-semibold text-pink-700 mb-2">Customized Gift Boxes</h3>
          <p class="text-gray-600">Beautifully crafted gift boxes tailored for your loved ones, filled with handpicked items.</p>
        </div>
        
        <!-- Service 3 -->
        <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
          <img src="images/eventDecorations.jpg" alt="Event Decorations" class="w-full h-40 object-cover rounded-lg mb-4">
          <h3 class="text-xl font-semibold text-pink-700 mb-2">Event Decorations</h3>
          <p class="text-gray-600">Stunning decorations for events like weddings, corporate gatherings, and private parties.</p>
        </div>
        
        <!-- Service 4 -->
        <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
          <img src="images/bridalBoquets.jpg" alt="Bridal Bouquets" class="w-full h-40 object-cover rounded-lg mb-4">
          <h3 class="text-xl font-semibold text-pink-700 mb-2">Bridal Bouquets</h3>
          <p class="text-gray-600">Exquisite bridal bouquets designed to complement your wedding theme and style.</p>
        </div>
        
        <!-- Service 5 -->
        <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
          <img src="images/seasonalFlowers.jpg" alt="Seasonal Flowers" class="w-full h-40 object-cover rounded-lg mb-4">
          <h3 class="text-xl font-semibold text-pink-700 mb-2">Seasonal Flowers</h3>
          <p class="text-gray-600">A wide range of seasonal flowers to brighten up your day or your home.</p>
        </div>
        
        <!-- Service 6 -->
        <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
          <img src="images/customOrders.jpg" alt="Custom Orders" class="w-full h-40 object-cover rounded-lg mb-4">
          <h3 class="text-xl font-semibold text-pink-700 mb-2">Custom Orders</h3>
          <p class="text-gray-600">Personalized flower arrangements and gift creations to meet your unique preferences and requirements.</p>
        </div>
      </div>
    </div>
  </section>

  <?php include('footer.php'); ?>
</body>
</html>
