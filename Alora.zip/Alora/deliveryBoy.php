<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Delivery Boy Page</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">

<!-- Navbar -->
<nav class="bg-blue-600 text-white px-6 py-4 shadow-md">
  <div class="container mx-auto flex justify-between items-center">
    <h1 class="text-2xl font-bold">Delivery Dashboard</h1>
    <button class="bg-blue-700 px-4 py-2 rounded-md hover:bg-blue-800">Logout</button>
  </div>
</nav>

<!-- Main Content -->
<div class="container mx-auto flex-1 py-8 px-4">
  <!-- Dashboard Header -->
  <div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-semibold text-gray-700">Welcome, John Doe</h2>
    <button class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">View Profile</button>
  </div>

  <!-- Assigned Deliveries Section -->
  <div class="bg-white shadow-md rounded-lg p-6 mb-6">
    <h3 class="text-xl font-bold text-gray-700 mb-4">Assigned Deliveries</h3>
    <table class="w-full table-auto">
      <thead class="bg-gray-200 text-gray-600">
        <tr>
          <th class="px-4 py-2 text-left">Order ID</th>
          <th class="px-4 py-2 text-left">Customer</th>
          <th class="px-4 py-2 text-left">Address</th>
          <th class="px-4 py-2 text-left">Status</th>
          <th class="px-4 py-2 text-left">Action</th>
        </tr>
      </thead>
      <tbody id="deliveryTable" class="text-gray-700">
        <!-- Example Row -->
        <tr>
          <td class="px-4 py-2">#12345</td>
          <td class="px-4 py-2">Alice Brown</td>
          <td class="px-4 py-2">123 Maple Street, NY</td>
          <td class="px-4 py-2">
            <span class="bg-yellow-500 text-white px-2 py-1 rounded-md text-sm">Pending</span>
          </td>
          <td class="px-4 py-2">
            <button class="bg-blue-600 text-white px-3 py-1 rounded-md hover:bg-blue-700" onclick="updateStatus('12345', 'Delivered')">Mark as Delivered</button>
          </td>
        </tr>
        <!-- More rows can be dynamically added here -->
      </tbody>
    </table>
  </div>

  <!-- Notifications Section -->
  <div class="bg-white shadow-md rounded-lg p-6 mb-6">
    <h3 class="text-xl font-bold text-gray-700 mb-4">Notifications</h3>
    <ul class="space-y-2">
      <li class="bg-gray-100 px-4 py-2 rounded-md">
        <span class="text-gray-600">You have a new delivery assigned: Order #54321.</span>
      </li>
      <li class="bg-gray-100 px-4 py-2 rounded-md">
        <span class="text-gray-600">Order #12345 needs immediate attention.</span>
      </li>
    </ul>
  </div>
</div>

<!-- Footer -->
<footer class="bg-pink-800 py-4">
    <div class="container mx-auto px-4 text-center">
      <p>&copy; 2024 ALORA Blossom & Gift Garden. All Rights Reserved.</p>
    </div>
  </footer>

<script>
  // Example JavaScript function to update delivery status
  function updateStatus(orderId, status) {
    // Simulate status update
    alert(`Order #${orderId} marked as ${status}`);
    
    // Update the status badge in the table (for demo purposes)
    const tableRow = document.querySelector(`#deliveryTable tr td:first-child:contains('${orderId}')`).parentNode;
    if (tableRow) {
      const statusCell = tableRow.querySelector("td:nth-child(4)");
      statusCell.innerHTML = `<span class="bg-green-600 text-white px-2 py-1 rounded-md text-sm">${status}</span>`;
    }
  }
</script>

</body>
</html>
