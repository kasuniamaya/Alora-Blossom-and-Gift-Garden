<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Products - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <?php include('navbar.php'); ?>
</head>
<body class="bg-pink-50">

<section id="flowerBouquets" class="py-16 bg-white">
  <div class="container mx-auto px-4">
    <h2 class="text-3xl font-bold text-pink-700 text-center mb-8">Our Flower Bouquets</h2>
    
    <!-- Initial display of first 8 products -->
    <div id="flowerList" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">

      <!-- Flower Bouquet 1 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose.png" alt="Flower 1" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 1</h3>
        <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
        <p class="text-gray-500 line-through mb-2">$30.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- Flower Bouquet 2 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose7.png" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
        <p class="text-gray-600 mb-4">An elegant arrangement of vibrant flowers.</p>
        <p class="text-gray-500 line-through mb-2">$35.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$25.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- Flower Bouquet 3 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose8.png" alt="Flower 3" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 3</h3>
        <p class="text-gray-600 mb-4">A premium bouquet for special occasions.</p>
        <p class="text-gray-500 line-through mb-2">$40.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$30.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- Flower Bouquet 4 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose9.png" alt="Flower 4" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 4</h3>
        <p class="text-gray-600 mb-4">A stunning bouquet of mixed flowers.</p>
        <p class="text-gray-500 line-through mb-2">$50.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$40.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- Flower Bouquet 5 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose10.png" alt="Flower 5" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 5</h3>
        <p class="text-gray-600 mb-4">A vibrant bouquet with a mix of seasonal flowers.</p>
        <p class="text-gray-500 line-through mb-2">$45.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$35.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- Flower Bouquet 6 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose11.png" alt="Flower 6" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 6</h3>
        <p class="text-gray-600 mb-4">Bright and cheerful flowers for any celebration.</p>
        <p class="text-gray-500 line-through mb-2">$50.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$40.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- Flower Bouquet 7 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose12.png" alt="Flower 7" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 7</h3>
        <p class="text-gray-600 mb-4">A delicate bouquet for the most elegant moments.</p>
        <p class="text-gray-500 line-through mb-2">$55.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$45.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

      <!-- Flower Bouquet 8 -->
      <div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
        <img src="images/rose13.png" alt="Flower 8" class="w-full h-56 object-cover rounded-lg mb-4">
        <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 8</h3>
        <p class="text-gray-600 mb-4">A stunning arrangement of red and white flowers.</p>
        <p class="text-gray-500 line-through mb-2">$60.00</p>
        <p class="text-lg font-semibold text-pink-600 mb-4">$50.00</p>
        <div class="flex space-x-4">
          <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
          <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
        </div>
      </div>

    </div>

    <!-- See More Button (Now Navigates to All Products Page) -->
    <div class="text-center mt-8">
      <a href="allProducts.php" class="text-pink-600 hover:text-pink-800 font-semibold">
        See More...
      </a>
    </div>
  </div>
</section>


<section id="flowerBouquets" class="py-16 bg-white">
  <div class="container mx-auto px-4">
    <h2 class="text-3xl font-bold text-pink-700 text-center mb-8">Our Gift Boxes</h2>

      <!-- Initial display of first 8 products -->
    <div id="flowerList" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">

<!-- gift box 1 -->
<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
  <img src="images/choko.jpg" alt="Flower 1" class="w-full h-56 object-cover rounded-lg mb-4">
  <h3 class="text-xl font-semibold text-pink-700 mb-2">Gift box 1</h3>
  <p class="text-gray-600 mb-4">A beautiful bouquet for every occasion.</p>
  <p class="text-gray-500 line-through mb-2">$30.00</p>
  <p class="text-lg font-semibold text-pink-600 mb-4">$20.00</p>
  <div class="flex space-x-4">
    <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
    <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
  </div>
</div>

<!-- gift box 2 -->
<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
  <img src="images/choko2.jpg" alt="Flower 2" class="w-full h-56 object-cover rounded-lg mb-4">
  <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 2</h3>
  <p class="text-gray-600 mb-4">An elegant arrangement of vibrant flowers.</p>
  <p class="text-gray-500 line-through mb-2">$35.00</p>
  <p class="text-lg font-semibold text-pink-600 mb-4">$25.00</p>
  <div class="flex space-x-4">
    <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
    <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
  </div>
</div>

<!-- gift box 3 -->
<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
  <img src="images/choko3.jpg" alt="Flower 3" class="w-full h-56 object-cover rounded-lg mb-4">
  <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 3</h3>
  <p class="text-gray-600 mb-4">A premium bouquet for special occasions.</p>
  <p class="text-gray-500 line-through mb-2">$40.00</p>
  <p class="text-lg font-semibold text-pink-600 mb-4">$30.00</p>
  <div class="flex space-x-4">
    <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
    <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
  </div>
</div>

<!-- gift box 4 -->
<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
  <img src="images/choko4.jpg" alt="Flower 4" class="w-full h-56 object-cover rounded-lg mb-4">
  <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 4</h3>
  <p class="text-gray-600 mb-4">A stunning bouquet of mixed flowers.</p>
  <p class="text-gray-500 line-through mb-2">$50.00</p>
  <p class="text-lg font-semibold text-pink-600 mb-4">$40.00</p>
  <div class="flex space-x-4">
    <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
    <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
  </div>
</div>

<!-- gift box 5 -->
<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
  <img src="images/choko5.jpg" alt="Flower 5" class="w-full h-56 object-cover rounded-lg mb-4">
  <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 5</h3>
  <p class="text-gray-600 mb-4">A vibrant bouquet with a mix of seasonal flowers.</p>
  <p class="text-gray-500 line-through mb-2">$45.00</p>
  <p class="text-lg font-semibold text-pink-600 mb-4">$35.00</p>
  <div class="flex space-x-4">
    <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
    <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
  </div>
</div>

<!-- gift box 6 -->
<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
  <img src="images/choko6.jpg" alt="Flower 6" class="w-full h-56 object-cover rounded-lg mb-4">
  <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 6</h3>
  <p class="text-gray-600 mb-4">Bright and cheerful flowers for any celebration.</p>
  <p class="text-gray-500 line-through mb-2">$50.00</p>
  <p class="text-lg font-semibold text-pink-600 mb-4">$40.00</p>
  <div class="flex space-x-4">
    <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
    <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
  </div>
</div>

<!-- gift box 7 -->
<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
  <img src="images/choko7.jpg" alt="Flower 7" class="w-full h-56 object-cover rounded-lg mb-4">
  <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 7</h3>
  <p class="text-gray-600 mb-4">A delicate bouquet for the most elegant moments.</p>
  <p class="text-gray-500 line-through mb-2">$55.00</p>
  <p class="text-lg font-semibold text-pink-600 mb-4">$45.00</p>
  <div class="flex space-x-4">
    <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
    <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
  </div>
</div>

<!-- gift box 8 -->
<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition-all">
  <img src="images/choko8.jpg" alt="Flower 8" class="w-full h-56 object-cover rounded-lg mb-4">
  <h3 class="text-xl font-semibold text-pink-700 mb-2">Flower Bouquet 8</h3>
  <p class="text-gray-600 mb-4">A stunning arrangement of red and white flowers.</p>
  <p class="text-gray-500 line-through mb-2">$60.00</p>
  <p class="text-lg font-semibold text-pink-600 mb-4">$50.00</p>
  <div class="flex space-x-4">
    <button class="w-full bg-pink-200 text-pink-600 py-2 rounded-lg hover:bg-pink-300 transition">Add to Cart</button>
    <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700 transition">Buy Now</button>
  </div>
</div>

</div>

<!-- See More Button (Now Navigates to chocolate products Page) -->
<div class="text-center mt-8">
<a href="choko.php" class="text-pink-600 hover:text-pink-800 font-semibold">
  See More...
</a>
</div>
</div>
</section>

  <?php include('footer.php'); ?>

</body>
</html>
