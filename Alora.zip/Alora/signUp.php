<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <?php include('navbar.php'); ?>
  <script>
    function validateSignUpForm(event) {
      event.preventDefault(); // Prevent form submission if validation fails

      var name = document.getElementById("name").value;
      var username = document.getElementById("username").value;
      var password = document.getElementById("password").value;
      var confirmPassword = document.getElementById("confirm-password").value;
      var contactNumber = document.getElementById("contact-number").value;
      var email = document.getElementById("email").value;

      var nameError = document.getElementById("name-error");
      var usernameError = document.getElementById("username-error");
      var passwordError = document.getElementById("password-error");
      var confirmPasswordError = document.getElementById("confirm-password-error");
      var contactNumberError = document.getElementById("contact-number-error");
      var emailError = document.getElementById("email-error");

      // Reset error messages
      nameError.textContent = "";
      usernameError.textContent = "";
      passwordError.textContent = "";
      confirmPasswordError.textContent = "";
      contactNumberError.textContent = "";
      emailError.textContent = "";

      var valid = true;

      // Validate Name
      if (name.trim() === "") {
        nameError.textContent = "Name is required.";
        valid = false;
      }

      // Validate Username
      if (username.trim() === "") {
        usernameError.textContent = "Username is required.";
        valid = false;
      }

      // Validate Password
      if (password.trim() === "") {
        passwordError.textContent = "Password is required.";
        valid = false;
      }

      // Validate Confirm Password
      if (confirmPassword.trim() === "") {
        confirmPasswordError.textContent = "Please confirm your password.";
        valid = false;
      } else if (password !== confirmPassword) {
        confirmPasswordError.textContent = "Passwords do not match.";
        valid = false;
      }

      // Validate Contact Number
      if (contactNumber.trim() === "" || !/^\d{10}$/.test(contactNumber)) {
        contactNumberError.textContent = "Enter a valid 10-digit contact number.";
        valid = false;
      }

      // Validate Email
      if (email.trim() === "") {
        emailError.textContent = "Email is required.";
        valid = false;
      } else if (!/\S+@\S+\.\S+/.test(email)) {
        emailError.textContent = "Enter a valid email address.";
        valid = false;
      }

      // If form is valid, submit it and navigate to the login page
      if (valid) {
        // Submit the form if validation is successful
        event.target.submit(); // This submits the form
        // Optionally, redirect to the login page after successful sign up
        // window.location.href = "login.php"; // Uncomment if redirect after success is needed
      }
    }
  </script>
</head>
<body class="bg-pink-50">

  <!-- Sign Up Section -->
  <section class="flex justify-center items-center min-h-screen bg-pink-50">
    <div class="bg-white rounded-lg shadow-lg p-8 w-full max-w-md">
      <h2 class="text-3xl font-bold text-pink-700 text-center mb-6">Sign Up</h2>
      
      <!-- Sign Up Form -->
      <form id="signup-form" onsubmit="validateSignUpForm(event)" method="POST" class="space-y-6">
        
        <!-- Name -->
        <div class="flex flex-col">
          <label for="name" class="text-pink-600">Name <span class="text-red-500">*</span></label>
          <input type="text" id="name" name="name" placeholder="Enter your name" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
          <p id="name-error" class="text-red-500 text-sm mt-2"></p>
        </div>

        <!-- Username -->
        <div class="flex flex-col">
          <label for="username" class="text-pink-600">Username <span class="text-red-500">*</span></label>
          <input type="text" id="username" name="username" placeholder="Enter your username" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
          <p id="username-error" class="text-red-500 text-sm mt-2"></p>
        </div>

        <!-- Password -->
        <div class="flex flex-col">
          <label for="password" class="text-pink-600">Password <span class="text-red-500">*</span></label>
          <input type="password" id="password" name="password" placeholder="Enter your password" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
          <p id="password-error" class="text-red-500 text-sm mt-2"></p>
        </div>

        <!-- Confirm Password -->
        <div class="flex flex-col">
          <label for="confirm-password" class="text-pink-600">Confirm Password <span class="text-red-500">*</span></label>
          <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm your password" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
          <p id="confirm-password-error" class="text-red-500 text-sm mt-2"></p>
        </div>

        <!-- Contact Number -->
        <div class="flex flex-col">
          <label for="contact-number" class="text-pink-600">Contact Number <span class="text-red-500">*</span></label>
          <input type="text" id="contact-number" name="contact-number" placeholder="Enter your contact number" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
          <p id="contact-number-error" class="text-red-500 text-sm mt-2"></p>
        </div>

        <!-- Email -->
        <div class="flex flex-col">
          <label for="email" class="text-pink-600">Email <span class="text-red-500">*</span></label>
          <input type="email" id="email" name="email" placeholder="Enter your email" class="mt-2 px-4 py-2 border border-pink-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
          <p id="email-error" class="text-red-500 text-sm mt-2"></p>
        </div>

        <!-- Sign Up Button -->
        <div>
          <button type="submit" class="bg-pink-600 text-white py-2 px-6 rounded-lg hover:bg-pink-700 transition">Sign Up</button>
        </div>
      </form>
    </div>
  </section>

  <?php include('footer.php'); ?>
</body>
</html>
