<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">

<!-- Admin Panel Container -->
<div class="container mx-auto py-8">
  <!-- Header -->
  <header class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-bold text-gray-700">Admin Panel</h1>
    <button id="addItemButton" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Add Item</button>
  </header>

  <!-- Items Table -->
  <div class="bg-white shadow-md rounded-lg overflow-hidden">
    <table class="min-w-full table-auto">
      <thead>
        <tr class="bg-gray-200 text-gray-700">
          <th class="px-4 py-2 text-left">ID</th>
          <th class="px-4 py-2 text-left">Item Name</th>
          <th class="px-4 py-2 text-left">Price</th>
          <th class="px-4 py-2 text-left">Actions</th>
        </tr>
      </thead>
      <tbody id="itemsTable">
        <!-- Dynamic Rows will be added here -->
      </tbody>
    </table>
  </div>
</div>

<!-- Add/Edit Item Modal -->
<div id="itemModal" class="fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center hidden">
  <div class="bg-white rounded-lg shadow-lg p-6 w-96">
    <h2 class="text-xl font-bold text-gray-700 mb-4" id="modalTitle">Add Item</h2>
    <form id="itemForm">
      <div class="mb-4">
        <label for="itemName" class="block text-sm font-medium text-gray-600">Item Name</label>
        <input type="text" id="itemName" class="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
      </div>
      <div class="mb-4">
        <label for="itemPrice" class="block text-sm font-medium text-gray-600">Price</label>
        <input type="number" id="itemPrice" class="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
      </div>
      <div class="flex justify-end space-x-2">
        <button type="button" id="cancelButton" class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400">Cancel</button>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
  // JavaScript for Admin Panel Functionality

  // DOM Elements
  const addItemButton = document.getElementById('addItemButton');
  const itemModal = document.getElementById('itemModal');
  const cancelButton = document.getElementById('cancelButton');
  const itemForm = document.getElementById('itemForm');
  const itemsTable = document.getElementById('itemsTable');
  const modalTitle = document.getElementById('modalTitle');
  const itemNameInput = document.getElementById('itemName');
  const itemPriceInput = document.getElementById('itemPrice');

  let editingItemId = null; // Tracks item being edited

  // Show Modal
  function showModal(editing = false, id = null) {
    if (editing) {
      modalTitle.textContent = 'Edit Item';
      const itemRow = document.getElementById(`item-${id}`);
      itemNameInput.value = itemRow.querySelector('.item-name').textContent;
      itemPriceInput.value = itemRow.querySelector('.item-price').textContent;
      editingItemId = id;
    } else {
      modalTitle.textContent = 'Add Item';
      itemNameInput.value = '';
      itemPriceInput.value = '';
      editingItemId = null;
    }
    itemModal.classList.remove('hidden');
  }

  // Hide Modal
  function hideModal() {
    itemModal.classList.add('hidden');
  }

  // Add Item to Table
  function addItemToTable(id, name, price) {
    const row = document.createElement('tr');
    row.id = `item-${id}`;
    row.innerHTML = `
      <td class="px-4 py-2">${id}</td>
      <td class="px-4 py-2 item-name">${name}</td>
      <td class="px-4 py-2 item-price">${price}</td>
      <td class="px-4 py-2">
        <button class="text-blue-600 hover:underline" onclick="editItem(${id})">Edit</button>
        <button class="text-red-600 hover:underline ml-2" onclick="deleteItem(${id})">Delete</button>
      </td>
    `;
    itemsTable.appendChild(row);
  }

  // Delete Item
  function deleteItem(id) {
    const itemRow = document.getElementById(`item-${id}`);
    itemRow.remove();
  }

  // Edit Item
  function editItem(id) {
    showModal(true, id);
  }

  // Handle Form Submit
  itemForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = itemNameInput.value.trim();
    const price = itemPriceInput.value.trim();

    if (!name || !price) {
      alert('Please fill out all fields.');
      return;
    }

    if (editingItemId) {
      // Update existing item
      const itemRow = document.getElementById(`item-${editingItemId}`);
      itemRow.querySelector('.item-name').textContent = name;
      itemRow.querySelector('.item-price').textContent = price;
    } else {
      // Add new item
      const id = Date.now();
      addItemToTable(id, name, price);
    }

    hideModal();
  });

  // Event Listeners
  addItemButton.addEventListener('click', () => showModal());
  cancelButton.addEventListener('click', hideModal);
</script>

<footer class="bg-pink-800 py-4">
    <div class="container mx-auto px-4 text-center">
      <p>&copy; 2024 ALORA Blossom & Gift Garden. All Rights Reserved.</p>
    </div>
  </footer>
</footer>

</body>
</html>
