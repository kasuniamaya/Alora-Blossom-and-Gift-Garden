<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Supporter Page</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">

<!-- Navbar -->
<nav class="bg-green-600 text-white px-6 py-4 shadow-md">
  <div class="container mx-auto flex justify-between items-center">
    <h1 class="text-2xl font-bold">Customer Support Dashboard</h1>
    <button class="bg-green-700 px-4 py-2 rounded-md hover:bg-green-800">Logout</button>
  </div>
</nav>

<!-- Main Content -->
<div class="container mx-auto flex-1 py-8 px-4">
  <!-- Dashboard Header -->
  <div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-semibold text-gray-700">Welcome, Support Agent</h2>
    <button class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">View Profile</button>
  </div>

  <!-- Open Tickets Section -->
  <div class="bg-white shadow-md rounded-lg p-6 mb-6">
    <h3 class="text-xl font-bold text-gray-700 mb-4">Open Tickets</h3>
    <table class="w-full table-auto">
      <thead class="bg-gray-200 text-gray-600">
        <tr>
          <th class="px-4 py-2 text-left">Ticket ID</th>
          <th class="px-4 py-2 text-left">Customer</th>
          <th class="px-4 py-2 text-left">Issue</th>
          <th class="px-4 py-2 text-left">Status</th>
          <th class="px-4 py-2 text-left">Action</th>
        </tr>
      </thead>
      <tbody id="ticketTable" class="text-gray-700">
        <!-- Example Row -->
        <tr>
          <td class="px-4 py-2">#1001</td>
          <td class="px-4 py-2">Alice Brown</td>
          <td class="px-4 py-2">Payment Issue</td>
          <td class="px-4 py-2">
            <span class="bg-yellow-500 text-white px-2 py-1 rounded-md text-sm">Pending</span>
          </td>
          <td class="px-4 py-2">
            <button class="bg-blue-600 text-white px-3 py-1 rounded-md hover:bg-blue-700" onclick="resolveTicket('1001')">Mark as Resolved</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Customer Inquiries Section -->
  <div class="bg-white shadow-md rounded-lg p-6 mb-6">
    <h3 class="text-xl font-bold text-gray-700 mb-4">Customer Inquiries</h3>
    <div class="space-y-4">
      <!-- Example Inquiry -->
      <div class="bg-gray-100 p-4 rounded-md shadow-sm">
        <p class="text-gray-600"><strong>Customer:</strong> John Smith</p>
        <p class="text-gray-600"><strong>Query:</strong> How can I track my order?</p>
        <textarea class="mt-2 w-full p-2 border border-gray-300 rounded-md" rows="3" placeholder="Type your response here..."></textarea>
        <button class="mt-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">Send Response</button>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
<footer class="bg-pink-800 py-4">
    <div class="container mx-auto px-4 text-center">
      <p>&copy; 2024 ALORA Blossom & Gift Garden. All Rights Reserved.</p>
    </div>
  </footer>
</footer>

<script>
  // Example JavaScript function to mark tickets as resolved
  function resolveTicket(ticketId) {
    alert(`Ticket #${ticketId} marked as resolved!`);
    
    // Simulate updating the status badge in the table (for demo purposes)
    const tableRow = document.querySelector(`#ticketTable tr td:first-child:contains('${ticketId}')`).parentNode;
    if (tableRow) {
      const statusCell = tableRow.querySelector("td:nth-child(4)");
      statusCell.innerHTML = `<span class="bg-green-600 text-white px-2 py-1 rounded-md text-sm">Resolved</span>`;
    }
  }
</script>

</body>
</html>
