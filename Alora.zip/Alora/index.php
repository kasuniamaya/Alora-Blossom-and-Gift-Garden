<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-pink-50">

  <!-- Navigation Bar -->
  <nav class="bg-pink-800 py-4 text-white">
    <div class="container mx-auto flex items-center justify-between px-4 py-2">
       <!-- Logo -->
     <div class="flex items-center space-x-2">
        <img src="images/logo1.png" alt="ALORA Logo" class="w-20 h-15">
      </div>

      <!-- Search Bar -->
      <div class="relative flex-1 mx-4">
        <input 
          type="text" 
          class="w-full px-4 py-2 rounded-lg border border-yellow-400 focus:outline-none"
          placeholder="Search the entire store..."
        />
        <button class="absolute right-2 top-2 bg-yellow-400 p-2 rounded-lg">
          <svg class="w-4 h-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </button>
      </div>

      <!-- User Options -->
      <div class="flex space-x-6">
        <a href="#" class="hover:text-yellow-400">Eng</a>
        <a href="#" class="hover:text-yellow-400">
          <svg class="w-5 h-5 inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h18M9 9l-6 6m0 0l6 6m-6-6h18" />
          </svg>
        </a>
        <a href="cart.php" class="hover:text-yellow-400">
          <svg class="w-5 h-5 inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h18M9 9l-6 6m0 0l6 6m-6-6h18" />
          </svg>
        </a>
        <a href="login.php" class="hover:text-yellow-400">
          <svg class="w-5 h-5 inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 11h14M11 17l-6-6m6 6l6-6" />
          </svg>
        </a>
      </div>
    </div>

  </nav>
  
    <!-- Secondary Navigation -->
    <div class="bg-pink-100 shadow-md text-gray-700 py-2">
      <div class="container mx-auto flex items-center justify-between px-4">
        <button class="flex items-center space-x-2 hover:text">
          <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16" />
          </svg>
          <span>All Categories</span>
        </button>
        <div class="flex space-x-6">
          <a href="index.php" class="hover:text">Home</a>
          <a href="aboutUs.php" class="hover:text">About Us</a>
          <a href="allProducts.php" class="hover:text">Products</a>
          <a href="faq.php" class="hover:text">FAQs</a>
          <a href="contactUs.php" class="hover:text">Contact Us</a>
          <a href="services.php "class="hover:text">Services</a>
          <a href="points.php" class="hover:text">Points</a>
        </div>

            <!-- Price Filter Section -->

<div class="mt-2">
  <label for="price" class="block text-gray-700">Products order To</label>
  <select id="price" name="price" class="form-select text-purple-600 mt-1 block w-full">
    <option value="best-sellers">Best Sellers</option>
    <option value="low-to-high">Low to High</option>
    <option value="high-to-low">High to Low</option>
  </select>
</div>

      </div>
    </div>

  <!-- Hero Section -->
  <section id="home" class="bg-gradient-to-r from-pink-100 via-pink-200 to-pink-300 py-40">
    <div class="container mx-auto px-4 text-center">
      <h1 class="text-4xl md:text-5xl font-extrabold text-pink-700">Welcome to ALORA Blossom & Gift Garden</h1>
      <p class="text-pink-600 mt-4 text-lg">Discover the beauty of flowers and unique gift boxes for every occasion.</p>
      <a href="#products" class="mt-6 inline-block bg-pink-600 text-white px-6 py-3 rounded-lg shadow-md hover:bg-pink-700">
        Shop Now
      </a>
    </div>
  </section>


  
  <!-- Offers Section -->
<section id="offers" class="relative py-16 bg-pink-100 overflow-hidden">
  <!-- Animation Canvas -->
  <canvas id="offersAnimation" class="absolute inset-0 z-0"></canvas>

  <div class="relative container mx-auto px-4 z-10">
    <div class="bg-white rounded-lg shadow-lg p-8">
      <h2 class="text-3xl font-bold text-pink-700 text-center">Special Offers</h2>
      <p class="text-pink-600 text-center mt-4">Enjoy our exclusive deals and discounts available for a limited time!</p>
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 mt-8">
        
        <!-- Offer 1 -->
        <div class="relative group bg-gradient-to-r from-pink-400 via-red-400 to-orange-400 rounded-lg p-6 shadow-lg flex flex-col justify-between">
          <div>
            <h3 class="text-xl font-bold text-white">Buy One Get One Free</h3>
            <p class="text-white mt-2">On select bouquets. Offer valid until January 31, 2025.</p>
          </div>
          <button class="mt-4 w-full bg-white text-pink-700 font-semibold py-2 rounded-lg hover:bg-pink-600 hover:text-white transition-all">Shop Now</button>
        </div>
        
        <!-- Offer 2 -->
        <div class="relative group bg-gradient-to-r from-blue-400 via-teal-400 to-green-400 rounded-lg p-6 shadow-lg flex flex-col justify-between">
          <div>
            <h3 class="text-xl font-bold text-white">Flat 20% Off</h3>
            <p class="text-white mt-2">On all gift boxes. Use code <span class="font-bold">ALORA20</span> at checkout.</p>
          </div>
          <button class="mt-4 w-full bg-white text-green-700 font-semibold py-2 rounded-lg hover:bg-green-600 hover:text-white transition-all">Shop Now</button>
        </div>

        <!-- Offer 3 -->
        <div class="relative group bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 rounded-lg p-6 shadow-lg flex flex-col justify-between">
          <div>
            <h3 class="text-xl font-bold text-white">Free Shipping</h3>
            <p class="text-white mt-2">On orders over $50. No code required!</p>
          </div>
          <button class="mt-4 w-full bg-white text-orange-700 font-semibold py-2 rounded-lg hover:bg-orange-600 hover:text-white transition-all">Shop Now</button>
        </div>

      </div>
    </div>
  </div>
</section>


<script>
  const canvas = document.getElementById('offersAnimation');
  const ctx = canvas.getContext('2d');

  // Set canvas dimensions
  function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = document.getElementById('offers').offsetHeight;
  }
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  // Create particles
  const particles = [];
  const colors = ['#ffafcc', '#ffcc29', '#ff5959', '#9b5de5', '#00bbf9', '#00f5d4'];

  function createParticle() {
    return {
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: Math.random() * 5 + 2,
      color: colors[Math.floor(Math.random() * colors.length)],
      velocityX: (Math.random() - 0.5) * 2,
      velocityY: (Math.random() - 0.5) * 2,
    };
  }

  for (let i = 0; i < 100; i++) {
    particles.push(createParticle());
  }

  // Update particles
  function updateParticles() {
    particles.forEach(particle => {
      particle.x += particle.velocityX;
      particle.y += particle.velocityY;

      // Wrap particles around edges
      if (particle.x > canvas.width) particle.x = 0;
      if (particle.x < 0) particle.x = canvas.width;
      if (particle.y > canvas.height) particle.y = 0;
      if (particle.y < 0) particle.y = canvas.height;
    });
  }

  // Draw particles
  function drawParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(particle => {
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      ctx.fillStyle = particle.color;
      ctx.fill();
    });
  }

  // Animation loop
  function animate() {
    updateParticles();
    drawParticles();
    requestAnimationFrame(animate);
  }

  animate();
</script>

  <!-- Featured Products Section -->
  <section id="products" class="py-16 bg-white">
    <div class="container mx-auto px-4">
      <h2 class="text-3xl font-bold text-pink-700 text-center">Our Featured Products</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 mt-8">
        <!-- Product 1 -->
        <div class="bg-pink-50 rounded-lg shadow-lg p-4 flex flex-col">
          <img src="images/rose.png" alt="Rose" class="rounded-lg w-full h-48 object-cover">
          <h3 class="mt-4 text-lg font-bold text-pink-700">Rose Bouquets</h3>
          <p class="text-pink-600 mt-2">Elegant roses for special moments.</p>
          <div class="mt-auto">
            <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700">View More</button>
          </div>
        </div>
        <!-- Product 2 -->
        <div class="bg-pink-50 rounded-lg shadow-lg p-4 flex flex-col">
          <img src="images/choko.jpg" alt="gift boxes" class="rounded-lg w-full h-48 object-cover">
          <h3 class="mt-4 text-lg font-bold text-pink-700">Choco Gift Boxes</h3>
          <p class="text-pink-600 mt-2">Sweet surprises wrapped in elegance, perfect for every occasion.</p>
          <div class="mt-auto">
            <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700">View More</button>
          </div>
        </div>
        <!-- Product 3 -->
        <div class="bg-pink-50 rounded-lg shadow-lg p-4 flex flex-col">
          <img src="images/lili.jpg" alt="lili flowers" class="rounded-lg w-full h-48 object-cover">
          <h3 class="mt-4 text-lg font-bold text-pink-700">Lily Bouquet</h3>
          <p class="text-pink-600 mt-2">Pure and serene lily arrangements.</p>
          <div class="mt-auto">
            <button class="w-full bg-pink-600 text-white py-2 rounded-lg hover:bg-pink-700">View More</button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php include('footer.php'); ?>

</body>
</html>