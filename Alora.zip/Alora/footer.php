
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>

</head>
<body class="bg-pink-50">

  <!-- Footer -->
<footer class="bg-pink-700 text-white">
  <div class="container mx-auto px-4 py-8">
    <!-- Subscribe Section -->
    <div class="text-center mb-8">
      <h2 class="text-xl font-semibold">Subscribe to our mailing list!</h2>
      <form class="mt-4">
        <div class="flex justify-center items-center">
          <input
            type="email"
            placeholder="Email"
            class="p-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-pink-400"
          />
          <button
            type="submit"
            class="px-4 py-2 bg-pink-600 text-white font-semibold rounded-r-md hover:bg-pink-700"
          >
            →
          </button>
        </div>
      </form>
    </div>

    <!-- Footer Content -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8 border-t border-pink-800 pt-8">
      <!-- Quick Links -->
      <div>
        <h3 class="text-lg font-bold mb-4">Quick Links</h3>
        <ul class="space-y-2">
          
          <li><a href="index.php" class="hover:underline">Home</a></li>
          <li><a href="services.php" class="hover:underline">services</a></li>
          <li><a href="faq.php" class="hover:underline">FAQ</a></li>
          <li><a href="#" class="hover:underline">Privacy Policy</a></li>
          <li><a href="#" class="hover:underline">Shipping & Returns</a></li>
          <li><a href="#" class="hover:underline">Terms and Conditions</a></li>
        </ul>
      </div>

      <!-- Contact Information -->
      <div>
        <h3 class="text-lg font-bold mb-4">Get in Touch</h3>
        <p>
          Email: <a href="mailto:info@basketeer.lk" class="hover:underline">kasuniamaya001@gmail.com</a>
        </p>
        <p class="mt-2">Phone: 0776577096</p>
      </div>

      <!-- Branding -->
      <div>
        <h3 class="text-lg font-bold mb-4">ALORA</h3>
        <p class="mb-4">
          ALORA is your go-to for flowers & gifting. Shop pre-curated gifts, build your own custom flowers & gift box, or explore customized corporate flowers & gift options.
        </p>
        <!-- Social Icons -->
        <div class="flex space-x-4">
          <a href="#facebook" class="hover:text-pink-400">
            <i class="fab fa-facebook"></i>
          </a>
          <a href="#instagram" class="hover:text-pink-400">
            <i class="fab fa-instagram"></i>
          </a>
        </div>
      </div>
    </div>
  </div>

  <footer class="bg-pink-800 py-4">
    <div class="container mx-auto px-4 text-center">
      <p>&copy; 2024 ALORA Blossom & Gift Garden. All Rights Reserved.</p>
    </div>
  </footer>
</footer>

</body>
</html>
