

<?php
session_start();

// Mock cart data (replace with your database/session logic)
$_SESSION['cart'] = [
    [
        'id' => 1,
        'name' => 'Rose Bouquet',
        'price' => 20.00,
        'quantity' => 2,
        'image' => 'images/rose.png'
    ],
    [
        'id' => 2,
        'name' => 'Tulip Bouquet',
        'price' => 30.00,
        'quantity' => 1,
        'image' => 'images/rose12.png'
    ]
];

$cartItems = $_SESSION['cart'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - ALORA Blossom and Gift Garden</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        function updateTotal() {
            let total = 0;
            document.querySelectorAll(".cart-item").forEach(item => {
                const price = parseFloat(item.dataset.price);
                const quantity = parseInt(item.querySelector(".item-quantity").value);
                total += price * quantity;
            });
            document.getElementById("totalPrice").innerText = `$${total.toFixed(2)}`;
        }

        function removeItem(button, id) {
            // Remove the cart item (simulate with DOM changes here; add backend removal logic)
            button.closest(".cart-item").remove();
            updateTotal();
        }

        document.addEventListener("DOMContentLoaded", updateTotal);
    </script>
</head>
<body class="bg-pink-50">

    <?php include('navbar.php'); ?>

    <section id="cart" class="py-16 bg-pink-100">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-pink-700 mb-6 text-center">Your Shopping Cart</h2>

            <div class="bg-white shadow-lg rounded-lg p-6">
                <div class="grid grid-cols-5 font-bold text-gray-600 mb-4">
                    <p>Product</p>
                    <p>Price</p>
                    <p>Quantity</p>
                    <p>Total</p>
                    <p>Action</p>
                </div>

                <!-- Cart Items -->
                <div class="space-y-4">
                    <?php foreach ($cartItems as $item): ?>
                        <div class="grid grid-cols-5 items-center cart-item" data-price="<?= $item['price'] ?>">
                            <div class="flex items-center space-x-4">
                                <img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>" class="w-16 h-16 rounded-lg">
                                <p class="font-semibold text-pink-700"><?= $item['name'] ?></p>
                            </div>
                            <p class="item-price text-gray-700">$<?= number_format($item['price'], 2) ?></p>
                            <input type="number" value="<?= $item['quantity'] ?>" min="1" class="item-quantity w-16 p-2 border border-pink-300 rounded-lg text-center focus:outline-none focus:ring-2 focus:ring-pink-400" onchange="updateTotal()">
                            <p class="item-total text-gray-700">$<?= number_format($item['price'] * $item['quantity'], 2) ?></p>
                            <button class="text-red-500 hover:text-red-700" onclick="removeItem(this, <?= $item['id'] ?>)">Remove</button>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Cart Total -->
                <div class="mt-6 text-right">
                    <h3 class="text-2xl font-bold text-gray-700">Total: <span id="totalPrice">$0.00</span></h3>
                </div>

                <!-- Checkout Button -->
                <div class="mt-4 text-right">
                    <a href="checkout.php" class="bg-pink-600 text-white py-2 px-6 rounded-lg hover:bg-pink-700 transition">
                        Proceed to Checkout
                    </a>
                </div>
            </div>
        </div>
    </section>

    <?php include('footer.php'); ?>

</body>
</html>
