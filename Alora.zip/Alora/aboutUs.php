<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  
  <?php include('navbar.php'); ?>
</head>
<body class="bg-pink-50">



  <!-- About Us Section -->
  <section class="py-12 bg-pink-50">
    <div class="container mx-auto px-4">
      <h2 class="text-4xl font-bold text-pink-700 text-center mb-8">About Us</h2>
      
      <div class="max-w-4xl mx-auto text-center">
        <p class="text-lg text-gray-700 mb-6">At ALORA Blossom and Gift Garden, we specialize in creating stunning floral arrangements and personalized gift boxes. Our mission is to spread love and joy through beautiful blooms and thoughtful gifts, making every occasion special and memorable for our customers.</p>

        <p class="text-lg text-gray-700 mb-6">Whether you're celebrating a birthday, anniversary, or any special event, we offer a wide range of floral designs and gift options tailored to meet your needs. We take pride in our quality products and excellent customer service, ensuring that every gift you send is a perfect reflection of your sentiments.</p>

        <h3 class="text-2xl font-semibold text-pink-700 mb-4">Our Team</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          <!-- Team Member 1 -->
          <div class="bg-white p-6 rounded-lg shadow-lg text-center">
            <img src="images/person3.jpg" alt="Team Member" class="w-32 h-32 rounded-full mx-auto mb-4">
            <h4 class="text-xl font-semibold text-pink-700">Jane Doe</h4>
            <p class="text-gray-600">Founder & CEO</p>
          </div>
          
          <!-- Team Member 2 -->
          <div class="bg-white p-6 rounded-lg shadow-lg text-center">
            <img src="images/person1.jpg" alt="Team Member" class="w-32 h-32 rounded-full mx-auto mb-4">
            <h4 class="text-xl font-semibold text-pink-700">John Smith</h4>
            <p class="text-gray-600">Head Florist</p>
          </div>

          <!-- Team Member 3 -->
          <div class="bg-white p-6 rounded-lg shadow-lg text-center">
            <img src="images/person4.jpg" alt="Team Member" class="w-32 h-32 rounded-full mx-auto mb-4">
            <h4 class="text-xl font-semibold text-pink-700">Emily Johnson</h4>
            <p class="text-gray-600">Customer Relations Manager</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Contact Us Section -->
  <section class="py-12 bg-pink-100">
    <div class="container mx-auto px-4 text-center">
      <h3 class="text-3xl font-bold text-pink-700 mb-6">Get in Touch</h3>
      <p class="text-lg text-gray-700 mb-6">Have any questions or inquiries? Feel free to contact us anytime! We're here to help.</p>
      <a href="contactUs.php" class="bg-pink-600 text-white py-2 px-6 rounded-lg hover:bg-pink-700 transition">Contact Us</a>
    </div>
  </section>

  <?php include('footer.php'); ?>


</body>
</html>
