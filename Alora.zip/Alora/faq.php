<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FAQs - ALORA Blossom and Gift Garden</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <?php include('navbar.php'); ?>
  <script>
    function toggleAnswer(id) {
      var answer = document.getElementById(id);
      answer.classList.toggle('hidden');
    }
  </script>
</head>
<body class="bg-pink-50">

  <!-- FAQs Section -->
  <section class="py-12 bg-pink-50">
    <div class="container mx-auto px-4">
      <h2 class="text-3xl font-bold text-pink-700 text-center mb-8">Frequently Asked Questions</h2>

      <div class="space-y-4">
        <!-- Question 1 -->
        <div class="bg-white rounded-lg shadow-lg p-6">
          <button onclick="toggleAnswer('answer1')" class="w-full text-left text-lg font-semibold text-pink-700 hover:text-pink-800">
            What products do you offer?
          </button>
          <div id="answer1" class="hidden text-gray-600 mt-4">
            <p>We offer a variety of gift boxes and fresh flowers for all occasions including birthdays, anniversaries, weddings, and corporate events.</p>
          </div>
        </div>

        <!-- Question 2 -->
        <div class="bg-white rounded-lg shadow-lg p-6">
          <button onclick="toggleAnswer('answer2')" class="w-full text-left text-lg font-semibold text-pink-700 hover:text-pink-800">
            How can I place an order?
          </button>
          <div id="answer2" class="hidden text-gray-600 mt-4">
            <p>You can place an order directly through our website or by contacting our customer support team. Simply select the products you wish to purchase and follow the checkout process.</p>
          </div>
        </div>

        <!-- Question 3 -->
        <div class="bg-white rounded-lg shadow-lg p-6">
          <button onclick="toggleAnswer('answer3')" class="w-full text-left text-lg font-semibold text-pink-700 hover:text-pink-800">
            Do you offer same-day delivery?
          </button>
          <div id="answer3" class="hidden text-gray-600 mt-4">
            <p>Yes! We offer same-day delivery for orders placed before 12 PM, depending on the delivery location.</p>
          </div>
        </div>

        <!-- Question 4 -->
        <div class="bg-white rounded-lg shadow-lg p-6">
          <button onclick="toggleAnswer('answer4')" class="w-full text-left text-lg font-semibold text-pink-700 hover:text-pink-800">
            What is your return policy?
          </button>
          <div id="answer4" class="hidden text-gray-600 mt-4">
            <p>We offer a 7-day return policy for unused products. If you are not satisfied with your purchase, you can return it for a refund or exchange.</p>
          </div>
        </div>

        <!-- Question 5 -->
        <div class="bg-white rounded-lg shadow-lg p-6">
          <button onclick="toggleAnswer('answer5')" class="w-full text-left text-lg font-semibold text-pink-700 hover:text-pink-800">
            Can I customize my gift box?
          </button>
          <div id="answer5" class="hidden text-gray-600 mt-4">
            <p>Yes, we offer customization options for gift boxes. You can select from a variety of flowers, chocolates, and other gifts to create the perfect personalized package.</p>
          </div>
        </div>

        <!-- Question 6 -->
        <div class="bg-white rounded-lg shadow-lg p-6">
          <button onclick="toggleAnswer('answer6')" class="w-full text-left text-lg font-semibold text-pink-700 hover:text-pink-800">
            Do you offer international shipping?
          </button>
          <div id="answer6" class="hidden text-gray-600 mt-4">
            <p>Currently, we only offer domestic shipping. We are working towards expanding our delivery services to include international shipping in the future.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php include('footer.php'); ?>
</body>
</html>
